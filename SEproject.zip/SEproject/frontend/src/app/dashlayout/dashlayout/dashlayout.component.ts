import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashlayout',
  templateUrl: './dashlayout.component.html',
  styleUrls: ['./dashlayout.component.css']
})
export class DashlayoutComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
