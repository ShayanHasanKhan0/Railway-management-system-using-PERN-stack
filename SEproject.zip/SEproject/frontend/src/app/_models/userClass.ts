export class User {
    name: string;
    userName: string;
    nonce: string;
    customerid: string;
}
