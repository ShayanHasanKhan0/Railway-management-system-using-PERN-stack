export interface OrgItem {
    id?: string,
    name: string,
    parent?: string,
    root?: string,
    level: number,
    description: string
}
